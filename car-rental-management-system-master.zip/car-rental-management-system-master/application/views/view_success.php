<div id="page-wrapper">
	<div class="row">
		<div class="col-lg-12">
			<h1>Successfully Added</h1>
		</div>
	</div>
</div>